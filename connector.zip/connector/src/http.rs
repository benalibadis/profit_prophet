use reqwest::{Client, Method};
use serde::de::DeserializeOwned;
use serde::Serialize;
use std::collections::HashMap;
use std::time::Duration;
use tokio::time::timeout;

#[derive(Debug, thiserror::Error)]
pub enum HttpClientError {
    #[error("Request error: {0}")]
    RequestError(#[from] reqwest::Error),
    #[error("Timeout error: {0}")]
    TimeoutError(#[from] tokio::time::error::Elapsed),
    #[error("Failed to deserialize response: {0}")]
    DeserializeError(String),
    #[error("Invalid HTTP method: {0}")]
    InvalidMethodError(String),
}

#[derive(Clone, Debug)]
pub struct HttpClient {
    client: Client,
}

impl HttpClient {
    pub fn new() -> Self {
        HttpClient {
            client: Client::new(),
        }
    }

    pub async fn request<T: DeserializeOwned, U: Serialize + std::fmt::Debug>(
        &self,
        method: &str,
        url: &str,
        body: Option<&U>,
        headers: Option<HashMap<String, String>>,
        query_params: Option<HashMap<String, String>>,
        timeout_duration: Option<Duration>,
    ) -> Result<T, HttpClientError> {
        
        let method: Method = method.parse().map_err(|_| HttpClientError::InvalidMethodError(method.to_string()))?;
        
        let mut request_builder = self.client.request(method.clone(), url);

        if let Some(ref h) = headers {
            for (key, value) in h {
                request_builder = request_builder.header(key, value);
            }
        }

        if let Some(params) = query_params {
            request_builder = request_builder.query(&params);
        }


        if let Some(b) = body {
            if let Some(content_type) = headers.as_ref().and_then(|h| h.get("Content-Type")) {
                match content_type.as_str() {
                    "application/json" => {
                        request_builder = request_builder.json(b);
                    }
                    "application/x-www-form-urlencoded" => {
                        if let Some(form_body) = serde_urlencoded::to_string(b).ok() {
                            request_builder = request_builder.body(form_body);
                        }
                    }
                    "text/plain" => {
                        if let Ok(text_body) = serde_json::to_string(b) {
                            let text_body = text_body.replace("\\\"", "\"").trim_matches('"').to_string();
                            request_builder = request_builder.body(text_body);
                        }
                    }
                    _ => {
                        // Handle other content types if necessary
                        request_builder = request_builder.json(b);
                    }
                }
            } else {
                request_builder = request_builder.json(b);
            }
        }

        let request = request_builder.build()?;
        let response = match timeout_duration {
            Some(duration) => timeout(duration, self.client.execute(request)).await??,
            None => self.client.execute(request).await?,
        };

        let response_text = response.text().await.map_err(HttpClientError::RequestError)?;

        serde_json::from_str::<T>(&response_text).map_err(|_| HttpClientError::DeserializeError(response_text))
    }
}

impl Default for HttpClient {
    fn default() -> Self {
        Self::new()
    }
}
